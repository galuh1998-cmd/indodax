<?php
$telegramChatID = "1999061265";
$telegramBotToken  = "7547046048:AAG-c66q_1tl3wpIcAB7WedpbDdU-LYPYxc";
?>